#include "Types.h"

bool IsManufacturingDevice( DWORD, const WORD, const WORD)
{
    return true;
}
bool HidUartIndexToHidDeviceIndex( DWORD &, const WORD, const WORD)
{
    return true;
}
