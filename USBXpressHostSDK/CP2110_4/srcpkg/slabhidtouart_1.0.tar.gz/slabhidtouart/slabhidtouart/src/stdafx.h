#ifndef __STDAFX_H__
#define __STDAFX_H__

#include "OsDep.h"

#endif // __STDAFX_H__
